<?php

/**
 * @file
 * Default theme implementation to display a single Drupal page.
 *
 * The doctype, html, head and body tags are not in this template. Instead they
 * can be found in the html.tpl.php template in this directory.
 *
 * Available variables:
 *
 * General utility variables:
 * - $base_path: The base URL path of the Drupal installation. At the very
 *   least, this will always default to /.
 * - $directory: The directory the template is located in, e.g. modules/system
 *   or themes/bartik.
 * - $is_front: TRUE if the current page is the front page.
 * - $logged_in: TRUE if the user is registered and signed in.
 * - $is_admin: TRUE if the user has permission to access administration pages.
 *
 * Site identity:
 * - $front_page: The URL of the front page. Use this instead of $base_path,
 *   when linking to the front page. This includes the language domain or
 *   prefix.
 * - $logo: The path to the logo image, as defined in theme configuration.
 * - $site_name: The name of the site, empty when display has been disabled
 *   in theme settings.
 * - $site_slogan: The slogan of the site, empty when display has been disabled
 *   in theme settings.
 *
 * Navigation:
 * - $main_menu (array): An array containing the Main menu links for the
 *   site, if they have been configured.
 * - $secondary_menu (array): An array containing the Secondary menu links for
 *   the site, if they have been configured.
 * - $breadcrumb: The breadcrumb trail for the current page.
 *
 * Page content (in order of occurrence in the default page.tpl.php):
 * - $title_prefix (array): An array containing additional output populated by
 *   modules, intended to be displayed in front of the main title tag that
 *   appears in the template.
 * - $title: The page title, for use in the actual HTML content.
 * - $title_suffix (array): An array containing additional output populated by
 *   modules, intended to be displayed after the main title tag that appears in
 *   the template.
 * - $messages: HTML for status and error messages. Should be displayed
 *   prominently.
 * - $tabs (array): Tabs linking to any sub-pages beneath the current page
 *   (e.g., the view and edit tabs when displaying a node).
 * - $action_links (array): Actions local to the page, such as 'Add menu' on the
 *   menu administration interface.
 * - $feed_icons: A string of all feed icons for the current page.
 * - $node: The node object, if there is an automatically-loaded node
 *   associated with the page, and the node ID is the second argument
 *   in the page's path (e.g. node/12345 and node/12345/revisions, but not
 *   comment/reply/12345).
 *
 * Regions:
 * - $page['help']: Dynamic help text, mostly for admin pages.
 * - $page['highlighted']: Items for the highlighted content region.
 * - $page['content']: The main content of the current page.
 * - $page['sidebar_first']: Items for the first sidebar.
 * - $page['sidebar_second']: Items for the second sidebar.
 * - $page['header']: Items for the header region.
 * - $page['footer']: Items for the footer region.
 *
 * @see template_preprocess()
 * @see template_preprocess_page()
 * @see template_process()
 * @see html.tpl.php
 *
 * @ingroup themeable
 */
?>
<div class="wrapper">
	<!-- top-->
	<div id="sticky-head" class="container-sticky">
		<header class="section group ">
			<div class="header">
			<div class="col span_7 top-header">
				<!--<img src="images/oc-logo.png" class="charity_log_top">-->
				<?php if ($logo): ?>
            <a href="<?php print check_url($front_page); ?>" title="<?php print t('Home'); ?>"><img src="<?php print $logo; ?>" class="charity_log_top" alt="<?php print t('Home'); ?>" /></a>
            <?php endif; ?>
			</div>
			<span class="menu" id="menu">
				&#9776 Menu
			</span>
			<div class="col span_5 menu-mob">
				<div id="menus" class="menus">   
				
				<?php if ($page['navigation']) :?>
				    <?php print drupal_render($page['navigation']); ?>
				    <?php else :
				    if (module_exists('i18n_menu')) {
				    $main_menu_tree = i18n_menu_translated_tree(variable_get('menu_main_links_source', 'main-menu'));
				    } else {
				    $main_menu_tree = menu_tree(variable_get('menu_main_links_source', 'main-menu')); 
				    }
				    print drupal_render($main_menu_tree);
				    endif; ?>

					<!--<div class="col span_5 header_links">
						<div class="about"><a href="#mission"> ABOUT OPEN CHARITY</a></div>
					</div>
					<div class="col span_2 header_links">
						<div class="blog"><a href="#blog">THE BLOG</a></div>
					</div>
					<div class="col span_3 header_links">
						<div class="joinus"><a href="">join us</a></div>
					</div>
				    -->
				</div>
			</div>
			</div>
		</header>
	</div>
	 <!--end top-->

	 <!-- image slide-->
		 
	<div class="section group " style="max-width: 100% !important">
				<!--slide images-->
		<div class="home-img">
            <div class="slide slide-home-img">
				<div id="block-block-1" class="home-img-content content">
					<div class="content">
					
					<?php if ($page['banner_text']): ?>
						<!--<h1>Sharing Ideas For Charities</h1>
						<p class="first-text">Many charities’ goals are similar, as is the functionality we require, but little shared working takes place.</p>
						<p class="second-text">By working together, driving shared areas of interest and influencing open source developments we can bring efficiencies, improve the digital experience for our users, and have great impact.</p>
						<p class="third-text">Together we can make a bigger difference.</p>-->
						<?php print render($page['banner_text']); ?>

						<?php endif; ?>
						
						<!--<h1>Sharing Ideas For Charities</h1>
						<p class="first-text">Many charities’ goals are similar, as is the functionality we require, but little shared working takes place.</p>
						<p class="second-text">By working together, driving shared areas of interest and influencing open source developments we can bring efficiencies, improve the digital experience for our users, and have great impact.</p>
						<p class="third-text">Together we can make a bigger difference.</p>-->
					</div>
				</div> <!-- /.block -->
			</div>
        </div>
		  
	</div>
	 <!-- end image-->
	 <!-- image-->
	 <div class="section group setup-next-event">
		 <div class="container-inner">
			<div class="col span_10">
				<div class="next_event">
				<!--<div>
					<span class="Event">Next Event :</span>  <b class="eventdate">June 23<sup>rd</sup> 2016 18:30 - 21-00</b>
				</div>
			   <br>
			   <div class="event-details">
				   Cancer Research UK, Angel Building ,407 St John Street , London E1v 4AD
			   </div>-->
				 <?php if ($page['events']): ?>
					<?php print render($page['events']) ?>
			  <?php endif; ?>
				 </div>
			</div>
			 <div class="col span_2">
				<div class="register">
					REGISTER
					
				</div>
			</div>
		 </div>
	 </div>
	 <!--end next-->
	 <!--start groups -->
	 <!--start spl groups 26-6-17 -->
	<div class="section group" style="background-color: #ffffff;">
		<div class="container-inner">
			<div class="col span_12">
		<!--start responsive content-->
		
		<?php if ($page['content']): ?>
					<?php print render($page['content']) ?>
			  <?php endif; ?>
		
		<!--end responsive content-->
			</div>
		</div>
	</div>
	<!--end spl groups 26-6-17 -->
	<div class="section group setup-get-involved">
		<h2 class="getin">
			GET INVOLVED
		</h2>
	</div>
	<div class="section group" style="background-color: #ffffff;">
		  <div class="container-inner">
			<center>
				<div class="involved">
					 <div class="col span_4">
					
						
						<div class="section group" >
							<img src="<?php print $base_path?>/<?php print $directory;?>/images/meetup.jpg">
						</div>
						<br>
						<div class="section group" >
						   <span class="we">WE DO MEETINGS</span> 
						</div>
						<br>
						<!--<div class="section group wedo" >
						We organise our meetings through the OpenCharity
						MeetUp group
						</div>-->
						<?php if ($page['content_left']): ?>
									<div class="section group wedo"><?php print render($page['content_left']) ?></div>
								<?php endif; ?>
						<div class="section group" >
							<div class="meetgroup">
							   MEETUP GROUP
							</div>
						</div>
					</div>

				
					<div class="col span_4">
					   <div class="section group" >
							<img src="<?php print $base_path?>/<?php print $directory;?>/images/cross.jpg" >
						</div>
						<br>
						<div class="section group" >
							<span class="we">WE COMMUNICATE</span>
						</div>
						<br>
						<!--<div class="section group wedo" >
						OpenCharity have a slack group for
						daily communication
						</div>-->
						<?php if ($page['content_center']): ?>
									<div class="section group wedo"><?php print render($page['content_center']) ?></div>
								<?php endif; ?>
						
						<div class="section group" >
							<div class="meetgroup">
							   SLACK GROUP
							</div>
						</div>
					</div>
					<div class="col span_4">
						<div class="section group" >
							<img src="<?php print $base_path?>/<?php print $directory;?>/images/collaburate.jpg" >
						</div>
						<br>
						<div class="section group" >
							<span class="we">WE COLLABORATE</span>
						</div>
						<br>
						<!--<div class="section group wedo" >
						We have Wiki group set up to share tools and documents
						</div>-->
						<?php if ($page['content_right']): ?>
									<div class="section group wedo"><?php print render($page['content_right']) ?></div>
								<?php endif; ?>
						<div class="section group" >
							<div class="meetgroup">
								WIKI GROUP
							</div>
						</div>
						<br><br>
					</div>
				</div>
			</center>
		  </div>
	  </div>

	 <!--end groups-->

		<div class="mission" id="mission">
		  <div class="container-inner">
			<center>
		<!--OUR mission-->
				<div class="section group">
				<?php if ($page['mission']): ?>
									<?php print render($page['mission']) ?>
								<?php endif; ?>
					<!--<h2  class="ormsn">
						OUR MISSION   
					</h2>
					<p class="msntxt">
						Charties and  Partners  collaborating and sharing open  solutions and ideas  to create  value  in the digital space
					</p>
					<p>
						<h3 class="msntxt2">
						If you are a charity or a supplier, we are  ready to  welcome you
						</h3>
					</p>-->
				</div>

				<div class="section group">
						<div class="col span_4 mission_setup">
							<div class="mission-content-wrapper">
								<img src="<?php print $base_path?>/<?php print $directory;?>/images/bulb.png" class="mission_logo">
								<?php if ($page['mission_left']): ?>
									<div class="mission_content"><?php print render($page['mission_left']) ?></div>
								<?php endif; ?>
								
								<!--<div class="mission_content">
									<br>
									<br>
									<p class="mission_heading">We help charities</p> 
									<p class="msncontent">
										Share knowledge  and  working  practice to make <br>
										the best  technology  choices
									</p>
									<br>
								</div>-->
							</div>
						</div>
						<div class="col span_4 mission_setup">
							<div class="mission-content-wrapper">
								<img src="<?php print $base_path?>/<?php print $directory;?>/images/gp.png" class="mission_logo">
								<?php if ($page['mission_center']): ?>
									<div class="mission_content"><?php print render($page['mission_center']) ?></div>
								<?php endif; ?>
								<!--<div class="mission_content">
									<br>
									<br>
									<p class="mission_heading"> We bring together</p> 
									<p class="msncontent">
										Charities and suppliers to the  charity  sector to <br>
										share best  practices
									</p>
									<br>
								</div>-->
							</div>
						</div>

						<div class="col span_4 mission_setup" >
							<div class="mission-content-wrapper last">
								<img src= "<?php print $base_path?>/<?php print $directory;?>/images/lk.png" class="mission_logo">
								<?php if ($page['mission_right']): ?>
									<div class="mission_content"><?php print render($page['mission_right']) ?></div>
								<?php endif; ?>
								<!--<div class="mission_content">
									<br>
									<br>
									<p class="mission_heading">We encourage</p> 
									<p class="msncontent">
										collaboration and innovation for the  good of<br>
										the charity sector
									</p>
									<br>
								</div>-->
							</div>   
						</div>
						<div class="section group">
							<br>
							<hr class="hr">

						</div>
				</div>
		<!--end mession-->
		<!--Members-->

				<div class="section group">
					
					<h2 class="ormsn">OUR MEMBERS</h2>
					<br />
				</div>

 
			   <div class="section group">

					 <section class="regular slider">
			
					 <?php if ($page['members']): ?>
									<div><?php print render($page['members']) ?></div>
								<?php endif; ?>
						<!--<div>
						  <img src="images/cancer reaserch.jpg" />
						</div>
						<div>
						 <img src="images/compocorp.jpg">
						</div>
						<div>
						  <img src="images/kop.jpg"  />
						</div>
						<div>
						  <img src="images/zin.jpg" >
						</div>
						<div>
						 <img src="images/comic.jpg" >
						</div>
						<div>
						  <img src="images/cancer reaserch.jpg" />
						</div>
						<div>
						 <img src="images/compocorp.jpg">
						</div>
						<div>
						  <img src="images/kop.jpg"  />
						</div>
						<div>
						  <img src="images/zin.jpg" >
						</div>
						<div>
						 <img src="images/comic.jpg" >
						</div>
						-->
					  </section>

			   </div>
			   
		<!--End Members-->
		<!--Blog-->
		</center>
		 </div>
		 <center>
				<div class="section group blog-section" id="blog">
					<div class="open-blog container">
			   
						<h2 class="ormsn" style="padding-top:1em; margin-top: 1em; ">
							BLOG
						</h2>
						
					   
					<!--start blog (replaced all blog content) 26-6-17 -->
					
						<div class="blogs"> 
							<div class="section group">
								
								<div class="slidew regularblog slider"  data-slick='{"slidesToShow": 4, "slidesToScroll": 4}'>
								 <?php if ($page['blog']): ?>
									<?php print render($page['blog']) ?>
								<?php endif; ?>
						
								<!--<div class="col span_3 ">
									<div class="col span_12 special-space-blogs">
										<b class="blog-text blog-primary-head">
											Online  Donations Special
										</b><br>
										<hr class="bloghr">
										<p class="blog-text">
											Lorem  ipsum dolor site amet,
											consectetur adipiscing elit, sed do
											eiusmod tempor incididunt ut  labore  et  dolore  magna aliqua.
										</p>
										<p>
											<hr class="bloghr">
										</p>
										<p class="blog-text"> 14 Nov  2014</p>
									</div>
								</div>
								<div class="col span_3 ">
									<div class="col span_12 special-space-blogs">
										<b class="blog-text blog-primary-head">
											Online  Donations Special
										</b>
										<br>
										<hr class="bloghr">
										<p class="blog-text">
											Lorem  ipsum dolor site amet,
											consectetur adipiscing elit, sed do
											eiusmod tempor incididunt ut  labore  et  dolore  magna aliqua.
										</p>
										<p>
											<hr class="bloghr">
										</p>
										<p class="blog-text"> 14 Nov  2014</p>
									</div>
								</div>
								<div class="col span_3 ">
									<div class="col span_12 special-space-blogs">
										<b class="blog-text blog-primary-head">
											Online  Donations Special
										</b>
										<br>
										<hr class="bloghr">
										<p class="blog-text">
											Lorem  ipsum dolor site amet,
											consectetur adipiscing elit, sed do
											eiusmod tempor incididunt ut  labore  et  dolore  magna aliqua.
										</p>
										<p>
											<hr class="bloghr">
										</p>
										<p class="blog-text"> 14 Nov  2014</p>
									</div>
								</div>
								<div class="col span_3 ">
									<div class="col span_12 special-space-blogs">
										<b class="blog-text blog-primary-head">
											Online  Donations Special
										</b>
										<br>
										<hr class="bloghr">
										<p class="blog-text">
											Lorem  ipsum dolor site amet,
											consectetur adipiscing elit, sed do
											eiusmod tempor incididunt ut  labore  et  dolore  magna aliqua.
										</p>
										<p>
											<hr class="bloghr">
										</p>
										<p class="blog-text"> 14 Nov  2014</p>
									</div>
								</div>
								<div class="col span_3 ">
									<div class="col span_12 special-space-blogs">
										<b class="blog-text blog-primary-head" style="color:#ff0000">
											Online  Donations Special
										</b><br>
										<hr class="bloghr">
										<p class="blog-text">
											Lorem  ipsum dolor site amet,
											consectetur adipiscing elit, sed do
											eiusmod tempor incididunt ut  labore  et  dolore  magna aliqua.
										</p>
										<p>
											<hr class="bloghr">
										</p>
										<p class="blog-text"> 14 Nov  2014</p>
									</div>
								</div>
								<div class="col span_3 ">
									<div class="col span_12 special-space-blogs">
										<b class="blog-text blog-primary-head" style="color:#ff0000">
											Online  Donations Special
										</b>
										<br>
										<hr class="bloghr">
										<p class="blog-text">
											Lorem  ipsum dolor site amet,
											consectetur adipiscing elit, sed do
											eiusmod tempor incididunt ut  labore  et  dolore  magna aliqua.
										</p>
										<p>
											<hr class="bloghr">
										</p>
										<p class="blog-text"> 14 Nov  2014</p>
									</div>
								</div>
								<div class="col span_3 ">
									<div class="col span_12 special-space-blogs">
										<b class="blog-text blog-primary-head" style="color:#ff0000">
											Online  Donations Special
										</b>
										<br>
										<hr class="bloghr">
										<p class="blog-text">
											Lorem  ipsum dolor site amet,
											consectetur adipiscing elit, sed do
											eiusmod tempor incididunt ut  labore  et  dolore  magna aliqua.
										</p>
										<p>
											<hr class="bloghr">
										</p>
										<p class="blog-text"> 14 Nov  2014</p>
									</div>
								</div>
								<div class="col span_3 ">
									<div class="col span_12 special-space-blogs">
										<b class="blog-text blog-primary-head" style="color:#ff0000">
											Online  Donations Special
										</b>
										<br>
										<hr class="bloghr">
										<p class="blog-text">
											Lorem  ipsum dolor site amet,
											consectetur adipiscing elit, sed do
											eiusmod tempor incididunt ut  labore  et  dolore  magna aliqua.
										</p>
										<p>
											<hr class="bloghr">
										</p>
										<p class="blog-text"> 14 Nov  2014</p>
									</div>
								</div>
											-->
											
								</div>
								
								
						</div>    
								 
					</div>
					 <!--end replace blog 26-6-17 -->
					

				 </div>
				 <!--end blog-->
					<div class="scnd-bg-blog">
			
				   <!-- second background for blog-->
					</div>
				</div> 
		<!--End Blog-->
		
			


			</center>

		</div>
	

		<!--bottom-->
		<div class="section group">
			<div class="span_12 bottom">
				<div class="bottom-section">
					<center>
						<div class="col span_12">
						<br>
							<span class="bottom-font bottom-icons">
							<img src="<?php print $base_path?>/<?php print $directory;?>/images/font-icon.png">
							</span>
							<br>  <br>
							<hr class="bottom-hr">
    
							<?php if ($page['footer']): ?>
							    <p>
							     <span class="bottom-primary-font"> 
							      <?php print render($page['footer']); ?>
							       </span>
							    </p> <!-- /footer -->
							  <?php endif; ?>	
							
							<!--<p>
							   <span class="bottom-primary-font"> Thois site was build as  a collaboration between  <span class="bottom-font">Manifesco  Digital</span>  and <span class="bottom-font">Compucorp</span>
							   </span>
							</p>-->
						</div>
						

					</center>
				</div>
			</div>
		</div>
		
	<!--end bottom-->
	</div>
		 <script type="text/javascript">
    $(document).on('ready', function() {
      $(".regular").slick({
        dots: true,
		arrows: false,
        infinite: true,
        slidesToShow: 5,
        slidesToScroll: 5,
		responsive: [ {
      breakpoint: 1024,
      settings: {
        slidesToShow: 5,
        slidesToScroll: 5,
        infinite: true,
        dots: true
      }
    },
	{
      breakpoint: 770,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3
      }
		},
		{
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
		},
		{
		  breakpoint: 480,
		  settings: {
			slidesToShow: 2,
			slidesToScroll: 2
		  }
		}
		// You can unslick at a given breakpoint now by adding:
		// settings: "unslick"
		// instead of a settings object
	  ]
      });
	   // start blog js 26-6-17 
	  $(".regularblog").slick({
        dots: false,
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 4,
		responsive: [ {
      breakpoint: 1024,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 4,
        infinite: true,
        dots: false
      }
    },
	{
      breakpoint: 770,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
		},
		{
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
		},
		{
		  breakpoint: 480,
		  settings: {
			slidesToShow: 1,
			slidesToScroll: 1
		  }
		}
		// You can unslick at a given breakpoint now by adding:
		// settings: "unslick"
		// instead of a settings object
	  ]
      });
	  // end blog js 26-6-17
    });
    </script>