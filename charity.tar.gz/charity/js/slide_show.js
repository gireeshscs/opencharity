(function($) {
    Drupal.behaviors.slideShow = {
        attach: function(context) {
            $(document).ready(function() {
              /*  $(".field-name-field-slides").flexslider({
                    animation: "slide",
                    slideshow: false,
		animation: "slide",
    animationLoop: false,
    itemWidth: 210,
    itemMargin: 5,
    minItems: 2,
    maxItems: 4	
                });
		*/
		         $(".regular").slick({
        dots: true,
		arrows: false,
        infinite: true,
        slidesToShow: 5,
        slidesToScroll: 5,
		responsive: [ {
      breakpoint: 1024,
      settings: {
        slidesToShow: 5,
        slidesToScroll: 5,
        infinite: true,
        dots: true
      }
    },
	{
      breakpoint: 770,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3
      }
		},
		{
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
		},
		{
		  breakpoint: 480,
		  settings: {
			slidesToShow: 2,
			slidesToScroll: 2
		  }
		}
		// You can unslick at a given breakpoint now by adding:
		// settings: "unslick"
		// instead of a settings object
	  ]
      });
            });
        }
    }
}(jQuery));