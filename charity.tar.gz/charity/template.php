<?php
/*
function charity_preprocess_html(&$variables) {
  $options = array(
    'group' => JS_THEME,
  );
  //drupal_add_js(drupal_get_path('theme', 'example'). '/foo.js', $options);
}
*/
function charity_preprocess_page(&$vars, $hook) {
  if (true) {
   // drupal_add_js(drupal_get_path('theme', 'charity') . '/slick.js');
    $vars['scripts'] = drupal_get_js(); // necessary in D7?
  }
  //drupal_add_js(drupal_get_path('theme', 'charity') . '/js/memberslider.js', array('scope'=>'footer'));
  drupal_add_js(drupal_get_path('theme', 'charity') . '/js/slick.js', array('scope'=>'footer'));
}

//drupal_add_js('sites/all/themes/charity/js/slick.js', array('scope'=>'footer'));
